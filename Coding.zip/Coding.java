package com.company;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class Coding {

    public static void main(String[] args) {


        HashMap<String, Integer> list1 = new HashMap<>();
        HashMap<String, Integer> list2 = new HashMap<>();
        System.out.println("Enter your budget");
        Scanner sc = new Scanner(System.in);
        int budget = sc.nextInt();
        while (true) {
            System.out.println("1. Add an item \n 2.Exit \n Enter your choice");
            int option = sc.nextInt();
            if (option == 1) {
                System.out.println("Enter product:");
                String product = sc.nextLine();
                int quantity = sc.nextInt();
                int price = sc.nextInt();
                if (price <= budget) {
                    list1.put(product, quantity);
                    list2.put(product, price);
                    budget -= price;
                    System.out.println("Remaining:" + budget);
                    continue;
                } else {
                    System.out.println("Overbudget");
                    continue;
                }
            } else if (option == 2) {
                break;
            }
        }

        System.out.println("Product \t Quantity \t Price ");
        for (Map.Entry<String ,Integer> map:list1.entrySet()){
            System.out.println(map.getKey()+"\t"+map.getValue()+"\t"+list2.get(map.getKey()));
        }
    }
}


