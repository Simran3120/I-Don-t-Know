package com.company;

import java.util.Scanner;

public class Pattern {
    public static void main(String[] args) {
        int i,j,k,l=1,n;

        n=5;
        for (i=1;i<=n;i++){

            for (j=0;j<=n-i;++j){
                System.out.print(" ");
            }

            for(k=1;k<=i;k++,l++){
                System.out.printf("%4c",(char)(l+64));
            }
            System.out.println("");
        }

    }
}
